import { motion, useReducedMotion } from "framer-motion";
import {
  Globe,
  Sparkles,
  MonitorSmartphone,
  Target,
  Palette,
  PenTool,
  Zap,
  Search,
  ArrowRight,
} from "lucide-react";
import { SERVICES, PROCESS } from "../data/portfolioData";

const ICONS: Record<string, typeof Globe> = {
  globe: Globe,
  sparkles: Sparkles,
  monitor: MonitorSmartphone,
  target: Target,
  palette: Palette,
  pen: PenTool,
  zap: Zap,
  search: Search,
};

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const } },
};

export default function ServicesAndProcess() {
  const reduced = useReducedMotion();
  const animation = reduced ? {} : { initial: "hidden" as const, whileInView: "show" as const, viewport: { once: true, margin: "-60px" } };

  return (
    <section id="services" className="relative px-5 py-24 md:px-8 md:py-32">
      <div className="pointer-events-none absolute left-[-10%] top-1/4 h-96 w-96 rounded-full bg-[#1d3a8f]/[0.12] blur-[130px]" />

      <div className="mx-auto max-w-7xl">
        {/* Section header */}
        <motion.div className="mx-auto max-w-2xl text-center" variants={fadeUp} {...animation}>
          <span className="eyebrow justify-center">Services</span>
          <h2 className="section-title mt-4">
            Everything you need to go <span className="gold-text">from idea to online.</span>
          </h2>
          <p className="mt-5 text-base leading-relaxed text-cream/55 md:text-lg">
            Eight specialized services, one goal: a website that represents your business at its best and performs for your growth.
          </p>
        </motion.div>

        {/* Services grid */}
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {SERVICES.map((service, i) => {
            const Icon = ICONS[service.icon] ?? Globe;
            return (
              <motion.div
                key={service.title}
                className="glass-card group relative overflow-hidden rounded-3xl p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-gold-500/35 hover:shadow-[0_24px_60px_-24px_rgba(212,175,55,0.25)]"
                initial={reduced ? { opacity: 1 } : { opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.55, delay: (i % 4) * 0.08, ease: [0.16, 1, 0.3, 1] as const }}
              >
                <div className="pointer-events-none absolute inset-x-0 top-0 h-px bg-gradient-to-r from-transparent via-gold-500/40 to-transparent opacity-0 transition-opacity duration-300 group-hover:opacity-100" />
                <div className="flex items-start justify-between">
                  <span className="flex h-12 w-12 items-center justify-center rounded-2xl bg-gold-500/12 text-gold-400 transition-all duration-300 group-hover:scale-110 group-hover:bg-gold-500/20">
                    <Icon size={22} strokeWidth={1.8} />
                  </span>
                  <span className="rounded-full border border-white/10 bg-white/[0.04] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-cream/40">
                    {service.tag}
                  </span>
                </div>
                <h3 className="mt-5 text-base font-bold leading-snug text-cream">{service.title}</h3>
                <p className="mt-2.5 text-sm leading-relaxed text-cream/55">{service.desc}</p>
              </motion.div>
            );
          })}
        </div>
      </div>

      {/* Process timeline */}
      <div id="process" className="mx-auto mt-28 max-w-7xl scroll-mt-28">
        <motion.div className="mx-auto max-w-2xl text-center" variants={fadeUp} {...animation}>
          <span className="eyebrow justify-center">My Process</span>
          <h2 className="section-title mt-4">
            A proven path from <span className="gold-text">discovery to launch.</span>
          </h2>
          <p className="mt-5 text-base leading-relaxed text-cream/55 md:text-lg">
            Five clear steps with zero guesswork. You stay informed at every stage of your project.
          </p>
        </motion.div>

        <div className="relative mt-16 grid gap-8 md:grid-cols-5 md:gap-4">
          {/* Connector line */}
          <div className="absolute left-0 right-0 top-[22px] hidden h-px bg-gradient-to-r from-gold-500/10 via-gold-500/35 to-gold-500/10 md:block" />

          {PROCESS.map((step, i) => (
            <motion.div
              key={step.index}
              className="relative flex flex-col items-center text-center"
              initial={reduced ? { opacity: 1 } : { opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{ duration: 0.6, delay: i * 0.12, ease: [0.16, 1, 0.3, 1] as const }}
            >
              <span className="relative z-10 flex h-11 w-11 items-center justify-center rounded-full border border-gold-500/40 bg-[#0a0f1c] font-mono text-sm font-bold text-gold-400 shadow-[0_0_24px_-6px_rgba(212,175,55,0.5)]">
                {step.index}
              </span>
              <h3 className="mt-5 text-base font-bold text-cream">{step.title}</h3>
              <p className="mt-2 max-w-[24ch] text-sm leading-relaxed text-cream/50">{step.desc}</p>
            </motion.div>
          ))}
        </div>

        <motion.div className="mt-16 text-center" variants={fadeUp} {...animation}>
          <a
            href="#contact"
            className="btn-ghost inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold"
          >
            Start Your Project
            <ArrowRight size={16} strokeWidth={2.2} />
          </a>
        </motion.div>
      </div>
    </section>
  );
}