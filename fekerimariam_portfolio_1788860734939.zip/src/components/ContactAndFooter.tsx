import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { PhoneCall, MessageCircle, Mail, Check, Copy, ArrowRight, MapPin } from "lucide-react";
import {
  BRAND,
  TIMELINE_CHOICES,
  BUDGET_CHOICES,
  whatsappLink,
  mailtoProjectInquiry,
  NAV_LINKS,
} from "../data/portfolioData";

function CopyButton({ value }: { value: string }) {
  const [copied, setCopied] = useState(false);
  const copy = async () => {
    try {
      await navigator.clipboard.writeText(value);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard unavailable */
    }
  };
  return (
    <button
      onClick={copy}
      aria-label={`Copy ${value}`}
      className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/10 text-cream/50 transition-all hover:border-gold-500/50 hover:text-gold-400"
    >
      {copied ? <Check size={14} strokeWidth={2.4} /> : <Copy size={14} />}
    </button>
  );
}

export default function ContactAndFooter() {
  const reduced = useReducedMotion();
  const [timeline, setTimeline] = useState<string>(TIMELINE_CHOICES[0]);
  const [budget, setBudget] = useState<string>(BUDGET_CHOICES[0]);

  const inquiryBody = [
    "Hello Fekerimariam,",
    "",
    "I would like to start a website project.",
    "",
    `Timeline: ${timeline}`,
    `Budget range: ${budget}`,
    "Requirements: ",
    "",
    "Please contact me to discuss the next steps.",
  ].join(String.fromCharCode(10));

  const inquiryMailto = mailtoProjectInquiry("Project Inquiry - Web Design Project", inquiryBody);

  const fadeUp = {
    hidden: { opacity: 0, y: 30 },
    show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const } },
  };
  const animation = reduced ? {} : { initial: "hidden" as const, whileInView: "show" as const, viewport: { once: true, margin: "-60px" } };

  return (
    <>
      <section id="contact" className="relative px-5 py-24 scroll-mt-24 md:px-8 md:py-32">
        <div className="pointer-events-none absolute left-1/2 top-0 h-96 w-[60rem] -translate-x-1/2 rounded-full bg-[#d4af37]/[0.08] blur-[140px]" />

        <div className="relative mx-auto max-w-7xl">
          <motion.div className="mx-auto max-w-3xl text-center" variants={fadeUp} {...animation}>
            <span className="eyebrow justify-center">Contact</span>
            <h2 className="section-title mt-4">
              Have a business that needs a <span className="gold-text">better website?</span>
            </h2>
            <p className="mt-5 text-base leading-relaxed text-cream/55 md:text-lg">
              Tell me about your project and I will get back to you quickly. Call, WhatsApp, or send a project inquiry in one click.
            </p>
          </motion.div>

          {/* Direct contact cards */}
          <motion.div className="mt-12 grid gap-5 md:grid-cols-2" variants={fadeUp} {...animation}>
            {/* Phone */}
            <div className="glass-card flex flex-col gap-4 rounded-3xl p-7">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gold-500/15 text-gold-400">
                  <PhoneCall size={20} strokeWidth={1.8} />
                </span>
                <div>
                  <p className="text-sm font-bold text-cream">Call me directly</p>
                  <p className="text-xs text-cream/45">Fastest way to reach me</p>
                </div>
              </div>
              <div className="space-y-2.5">
                {[
                  { n: BRAND.phonePrimary, f: "+251 913 602 094" },
                  { n: BRAND.phoneSecondary, f: "+251 708 175 310" },
                ].map((p) => (
                  <div
                    key={p.n}
                    className="flex items-center justify-between gap-3 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3 transition-colors hover:border-gold-500/35"
                  >
                    <a href={`tel:${p.n}`} className="flex items-center gap-3">
                      <span className="text-sm font-bold tracking-wide text-cream transition-colors hover:text-gold-400">
                        {p.f}
                      </span>
                    </a>
                    <CopyButton value={p.n} />
                  </div>
                ))}
              </div>
              <a
                href={`tel:${BRAND.phonePrimary}`}
                className="btn-gold inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-bold"
              >
                <PhoneCall size={15} strokeWidth={2.2} />
                Tap to Call
              </a>
            </div>

            {/* WhatsApp */}
            <div className="glass-card flex flex-col gap-4 rounded-3xl p-7">
              <div className="flex items-center gap-3">
                <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gold-500/15 text-gold-400">
                  <MessageCircle size={20} strokeWidth={1.8} />
                </span>
                <div>
                  <p className="text-sm font-bold text-cream">WhatsApp</p>
                  <p className="text-xs text-cream/45">Chat with a quick message</p>
                </div>
              </div>
              <p className="text-sm leading-relaxed text-cream/55">
                Prefer chatting? Send a WhatsApp message and I will reply as soon as I am free.
              </p>
              <a
                href={whatsappLink("Hello Fekerimariam, I would like to discuss a website project.")}
                target="_blank"
                rel="noreferrer"
                className="btn-gold inline-flex items-center justify-center gap-2 rounded-full px-5 py-3 text-sm font-bold"
              >
                <MessageCircle size={15} strokeWidth={2.2} />
                Chat on WhatsApp
              </a>
              <div className="flex items-center gap-2 rounded-2xl border border-white/10 bg-white/[0.03] px-4 py-3">
                <span className="flex-1 truncate text-xs text-cream/45">{BRAND.phonePrimaryIntl}</span>
                <CopyButton value={BRAND.phonePrimaryIntl} />
              </div>
            </div>
          </motion.div>

          {/* Inquiry helper */}
          <motion.div className="glass-card mt-8 rounded-3xl p-7 md:p-10" variants={fadeUp} {...animation}>
            <div className="flex flex-col gap-2">
              <h3 className="text-2xl font-extrabold tracking-tight text-cream">Start a Project</h3>
              <p className="text-sm leading-relaxed text-cream/50">
                Pick a timeline and budget, then send a pre-filled inquiry straight to my inbox.
              </p>
            </div>

            <div className="mt-7 grid gap-6 md:grid-cols-2">
              <div>
                <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-cream/40">Target timeline</p>
                <div className="flex flex-wrap gap-2">
                  {TIMELINE_CHOICES.map((t) => (
                    <button
                      key={t}
                      onClick={() => setTimeline(t)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-all duration-300 ${
                        timeline === t
                          ? "btn-gold"
                          : "border border-white/10 bg-white/[0.03] text-cream/60 hover:border-gold-500/40 hover:text-gold-400"
                      }`}
                    >
                      {t}
                    </button>
                  ))}
                </div>
              </div>
              <div>
                <p className="mb-3 text-xs font-semibold uppercase tracking-widest text-cream/40">Budget range</p>
                <div className="flex flex-wrap gap-2">
                  {BUDGET_CHOICES.map((b) => (
                    <button
                      key={b}
                      onClick={() => setBudget(b)}
                      className={`rounded-full px-4 py-2 text-sm font-medium transition-all duration-300 ${
                        budget === b
                          ? "btn-gold"
                          : "border border-white/10 bg-white/[0.03] text-cream/60 hover:border-gold-500/40 hover:text-gold-400"
                      }`}
                    >
                      {b}
                    </button>
                  ))}
                </div>
              </div>
            </div>

            <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:items-center">
              <a
                href={inquiryMailto}
                className="btn-gold group inline-flex items-center justify-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold"
              >
                <Mail size={15} strokeWidth={2.2} />
                Send Project Inquiry
                <ArrowRight size={15} strokeWidth={2.2} className="transition-transform duration-300 group-hover:translate-x-1" />
              </a>
              <span className="text-xs text-cream/40">
                Opens your mail app with timeline, budget, and requirements ready to send.
              </span>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Footer */}
      <footer className="relative border-t border-white/[0.07] px-5 py-12 md:px-8">
        <div className="mx-auto max-w-7xl">
          <div className="flex flex-col items-center gap-8 md:flex-row md:items-start md:justify-between">
            <div className="text-center md:text-left">
              <a href="#top" className="inline-flex items-center gap-3">
                <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-[#e5c05b] to-[#b8942a] text-sm font-extrabold text-[#0a0e18]">
                  FM
                </span>
                <span className="text-sm font-bold tracking-tight text-cream">Fekerimariam Mulat</span>
              </a>
              <p className="mt-3 flex items-center justify-center gap-1.5 text-xs text-cream/40 md:justify-start">
                <MapPin size={11} className="text-gold-500/70" />
                {BRAND.location}
              </p>
            </div>

            <nav className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
              {NAV_LINKS.map((link) => (
                <a key={link.href} href={link.href} className="text-sm text-cream/55 transition-colors hover:text-gold-400">
                  {link.label}
                </a>
              ))}
            </nav>

            <div className="flex items-center gap-3">
              <a
                href={`tel:${BRAND.phonePrimary}`}
                aria-label="Call"
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-cream/70 transition-all hover:border-gold-500/40 hover:text-gold-400"
              >
                <PhoneCall size={16} />
              </a>
              <a
                href={whatsappLink("Hello Fekerimariam, I would like to discuss a website project.")}
                target="_blank"
                rel="noreferrer"
                aria-label="WhatsApp"
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-cream/70 transition-all hover:border-gold-500/40 hover:text-gold-400"
              >
                <MessageCircle size={16} />
              </a>
              <a
                href={`mailto:${BRAND.email}`}
                aria-label="Email"
                className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/[0.04] text-cream/70 transition-all hover:border-gold-500/40 hover:text-gold-400"
              >
                <Mail size={16} />
              </a>
            </div>
          </div>

          <div className="gold-hairline mt-10" />

          <div className="mt-6 flex flex-col items-center justify-between gap-3 text-xs text-cream/35 md:flex-row">
            <p>© 2026 Fekerimariam Mulat. All Rights Reserved.</p>
            <p>Web Design & Digital Creation · {BRAND.location}</p>
          </div>
        </div>
      </footer>
    </>
  );
}