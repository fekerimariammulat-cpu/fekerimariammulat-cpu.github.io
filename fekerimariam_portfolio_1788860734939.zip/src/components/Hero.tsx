import { useState } from "react";
import { motion, useReducedMotion } from "framer-motion";
import { ArrowRight, PhoneCall, Copy, Check, MapPin, Globe, Zap, Sparkles, MonitorSmartphone, PenTool } from "lucide-react";
import { BRAND } from "../data/portfolioData";

const STATS = [
  { value: "8", label: "Specialized Services", icon: Sparkles },
  { value: "5", label: "Step Proven Process", icon: Zap },
  { value: "100%", label: "Responsive Builds", icon: MonitorSmartphone },
  { value: "Bespoke", label: "Custom Design", icon: PenTool },
];

function PhoneCard({ number, label }: { number: string; label: string }) {
  const [copied, setCopied] = useState(false);

  const copyNumber = async (e: React.MouseEvent) => {
    e.preventDefault();
    try {
      await navigator.clipboard.writeText(number);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch {
      /* clipboard unavailable */
    }
  };

  return (
    <div className="group relative flex items-center justify-between gap-4 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-3 transition-all hover:border-gold-500/40 hover:bg-white/[0.07]">
      <a href={`tel:${number}`} className="flex items-center gap-3">
        <span className="flex h-9 w-9 items-center justify-center rounded-xl bg-gold-500/15 text-gold-400">
          <PhoneCall size={16} strokeWidth={2.2} />
        </span>
        <span className="leading-tight">
          <span className="block text-[11px] uppercase tracking-widest text-cream/40">{label}</span>
          <span className="block text-sm font-bold tracking-wide text-cream transition-colors group-hover:text-gold-400">
            {number}
          </span>
        </span>
      </a>
      <button
        aria-label={`Copy ${number}`}
        onClick={copyNumber}
        className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-white/10 text-cream/50 transition-all hover:border-gold-500/50 hover:text-gold-400"
      >
        {copied ? <Check size={14} strokeWidth={2.4} /> : <Copy size={14} />}
      </button>
    </div>
  );
}

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.09, delayChildren: 0.15 } },
};

const item = {
  hidden: { opacity: 0, y: 28 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const } },
};

export default function Hero() {
  const reduced = useReducedMotion();

  return (
    <section id="top" className="relative flex min-h-[100dvh] flex-col items-center justify-center overflow-hidden px-5 pb-16 pt-32 md:px-8">
      {/* Aurora glows */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute -top-32 right-[-10%] h-[30rem] w-[30rem] rounded-full bg-[#d4af37]/[0.09] blur-[130px]" />
        <div className="absolute left-[-12%] top-1/3 h-[26rem] w-[26rem] rounded-full bg-[#1d3a8f]/20 blur-[120px]" />
        <div className="absolute bottom-[-20%] left-1/3 h-[24rem] w-[24rem] rounded-full bg-[#d4af37]/[0.06] blur-[110px]" />
      </div>

      <motion.div
        className="relative z-10 mx-auto flex max-w-4xl flex-col items-center text-center"
        variants={container}
        initial={reduced ? "show" : "hidden"}
        animate="show"
      >
        {/* Location badge */}
        <motion.div variants={item} className="mb-7">
          <span className="inline-flex items-center gap-2 rounded-full border border-gold-500/25 bg-gold-500/[0.07] px-4 py-1.5 text-xs font-medium tracking-wide text-gold-400">
            <MapPin size={13} />
            Based in Ethiopia · Serving Global & Local Businesses
          </span>
        </motion.div>

        {/* Headline */}
        <motion.h1
          variants={item}
          className="text-[2.6rem] font-extrabold leading-[1.04] tracking-tighter text-cream sm:text-6xl lg:text-7xl"
        >
          Modern Websites That Help Businesses{" "}
          <span className="gold-text">Stand Out.</span>
        </motion.h1>

        {/* Subtext */}
        <motion.p
          variants={item}
          className="mt-6 max-w-[56ch] text-base leading-relaxed text-cream/60 md:text-lg"
        >
          I am Fekerimariam, a web designer and digital creator in Addis Ababa crafting high-converting, modern, and bespoke digital experiences for businesses that want to be remembered.
        </motion.p>

        {/* CTAs */}
        <motion.div variants={item} className="mt-9 flex flex-col items-center gap-3 sm:flex-row">
          <a
            href="#work"
            className="btn-gold inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold"
          >
            View My Work
            <ArrowRight size={16} strokeWidth={2.4} />
          </a>
          <a href="#contact" className="btn-ghost inline-flex items-center gap-2 rounded-full px-7 py-3.5 text-sm font-bold">
            <PhoneCall size={16} strokeWidth={2.2} />
            Contact Me
          </a>
        </motion.div>

        {/* Phone cards */}
        <motion.div variants={item} className="mt-10 grid w-full max-w-md grid-cols-1 gap-3 sm:grid-cols-2">
          <PhoneCard number={BRAND.phonePrimary} label="Primary Line" />
          <PhoneCard number={BRAND.phoneSecondary} label="Secondary Line" />
        </motion.div>
      </motion.div>

      {/* Stats bar */}
      <motion.div
        className="relative z-10 mx-auto mt-14 grid w-full max-w-4xl grid-cols-2 gap-3 lg:grid-cols-4"
        initial={reduced ? { opacity: 1 } : { opacity: 0, y: 30 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.7, duration: 0.7, ease: [0.16, 1, 0.3, 1] as const }}
      >
        {STATS.map((s) => (
          <div
            key={s.label}
            className="glass-card flex flex-col items-center gap-2 rounded-2xl px-4 py-5 text-center"
          >
            <s.icon size={18} className="text-gold-400" strokeWidth={1.8} />
            <span className="text-2xl font-extrabold tracking-tight text-cream">{s.value}</span>
            <span className="text-[11px] font-medium uppercase tracking-widest text-cream/45">{s.label}</span>
          </div>
        ))}
      </motion.div>

      {/* Scroll hint */}
      <motion.a
        href="#about"
        aria-label="Scroll to about section"
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 text-cream/30 md:block"
        animate={reduced ? {} : { y: [0, 8, 0] }}
        transition={{ repeat: Infinity, duration: 2.2, ease: "easeInOut" }}
      >
        <Globe size={18} className="rotate-[0deg]" />
      </motion.a>
    </section>
  );
}