import { useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import {
  ArrowRight,
  ArrowUpRight,
  Check,
  X,
  Code,
  Briefcase,
  Mail,
} from "lucide-react";
import { CATEGORIES, PORTFOLIO, type PortfolioItem } from "../data/portfolioData";

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const } },
};

/* CSS-based concept mockups (browser chrome + structured content) */
function PatternBee({ tint }: { tint: string }) {
  return (
    <div
      className="relative h-full w-full overflow-hidden rounded-t-3xl"
      style={{ background: `linear-gradient(150deg, #141c30, #0a0f1c)` }}
    >
      <div
        className="absolute inset-0 opacity-30"
        style={{ background: `radial-gradient(60% 55% at 70% 20%, ${tint}55, transparent 70%)` }}
      />
      <div className="relative flex h-full flex-col justify-center px-7 text-center">
        <div className="mx-auto mb-4 h-2 w-16 rounded-full" style={{ background: `${tint}` }} />
        <div className="mx-auto h-2.5 w-3/4 rounded-full bg-white/60" />
        <div className="mx-auto mt-2 h-2.5 w-1/2 rounded-full bg-white/35" />
        <div className="mx-auto mt-7 flex gap-2">
          <span className="h-6 w-20 rounded-full" style={{ background: `${tint}` }} />
          <span className="h-6 w-14 rounded-full border border-white/25" />
        </div>
      </div>
    </div>
  );
}

function PatternGrid({ tint }: { tint: string }) {
  return (
    <div
      className="relative grid h-full w-full grid-cols-3 gap-3 overflow-hidden rounded-t-3xl p-5"
      style={{ background: `linear-gradient(150deg, #141c30, #0a0f1c)` }}
    >
      <div
        className="absolute inset-0 opacity-30"
        style={{ background: `radial-gradient(60% 55% at 30% 20%, ${tint}55, transparent 70%)` }}
      />
      {[0, 1, 2].map((col) => (
        <div key={col} className="relative flex flex-col gap-2 rounded-xl border border-white/[0.07] bg-white/[0.03] p-3">
          <div className="h-8 rounded-lg" style={{ background: `${tint}66` }} />
          <div className="h-1.5 w-4/5 rounded-full bg-white/40" />
          <div className="h-1.5 w-3/5 rounded-full bg-white/25" />
          <div className="mt-auto h-5 rounded-md" style={{ background: `${tint}88` }} />
        </div>
      ))}
    </div>
  );
}

function PatternSplit({ tint }: { tint: string }) {
  return (
    <div
      className="relative grid h-full w-full grid-cols-2 overflow-hidden rounded-t-3xl"
      style={{ background: `linear-gradient(150deg, #141c30, #0a0f1c)` }}
    >
      <div
        className="relative flex flex-col justify-center gap-2 border-r border-white/10 p-6"
        style={{ background: `radial-gradient(70% 70% at 20% 10%, ${tint}44, transparent 75%)` }}
      >
        <div className="h-2 w-10 rounded-full" style={{ background: `${tint}` }} />
        <div className="h-2.5 w-4/5 rounded-full bg-white/60" />
        <div className="h-2.5 w-3/5 rounded-full bg-white/30" />
        <div className="h-6 w-16 rounded-full" style={{ background: `${tint}` }} />
      </div>
      <div className="flex flex-col justify-center gap-2 p-6">
        <div className="h-6 w-1/2 rounded-lg" style={{ background: `${tint}88` }} />
        <div className="h-1.5 w-4/5 rounded-full bg-white/40" />
        <div className="h-1.5 w-1/2 rounded-full bg-white/25" />
        <div className="h-1.5 w-2/3 rounded-full bg-white/25" />
      </div>
    </div>
  );
}

function ConceptMock({ item }: { item: PortfolioItem }) {
  if (item.pattern === "grid") return <PatternGrid tint={item.tint} />;
  if (item.pattern === "split") return <PatternSplit tint={item.tint} />;
  return <PatternBee tint={item.tint} />;
}

function ProjectModal({ item, onClose }: { item: PortfolioItem; onClose: () => void }) {
  const reduced = useReducedMotion();

  return (
    <motion.div
      className="fixed inset-0 z-[80] flex items-end justify-center p-0 sm:items-center sm:p-6"
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.25 }}
      role="dialog"
      aria-modal="true"
      aria-label={item.title}
    >
      <div className="absolute inset-0 bg-[#04060c]/85 backdrop-blur-sm" onClick={onClose} />
      <motion.div
        className="relative max-h-[90dvh] w-full max-w-3xl overflow-y-auto rounded-t-3xl border border-white/10 bg-[#0a0f1c] shadow-2xl sm:rounded-3xl"
        initial={reduced ? { opacity: 1, y: 0 } : { opacity: 0, y: 60, scale: 0.96 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        exit={reduced ? { opacity: 0 } : { opacity: 0, y: 40, scale: 0.97 }}
        transition={{ duration: 0.32, ease: [0.16, 1, 0.3, 1] as const }}
      >
        {/* Mockup header */}
        <div className="relative h-52 overflow-hidden border-b border-white/10 sm:h-64">
          <div className="absolute inset-x-0 top-0 z-10 flex items-center gap-1.5 border-b border-white/[0.06] bg-[#0c1222]/90 px-4 py-3 backdrop-blur">
            <span className="h-2.5 w-2.5 rounded-full bg-[#ff5f57]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#febc2e]" />
            <span className="h-2.5 w-2.5 rounded-full bg-[#28c840]" />
            <span className="ml-3 h-5 flex-1 max-w-xs rounded-md bg-white/[0.06]" />
          </div>
          <ConceptMock item={item} />
          <button
            aria-label="Close project"
            onClick={onClose}
            className="absolute right-3 top-12 z-20 flex h-9 w-9 items-center justify-center rounded-xl border border-white/15 bg-[#0a0f1c]/90 text-cream transition-colors hover:border-gold-500/50 hover:text-gold-400"
          >
            <X size={16} />
          </button>
        </div>

        {/* Body */}
        <div className="p-6 sm:p-8">
          <div className="flex flex-wrap items-center gap-2">
            <span className="rounded-full border border-gold-500/30 bg-gold-500/10 px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-gold-400">
              {item.badge}
            </span>
            <span className="rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-cream/50">
              {item.category}
            </span>
            <span className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1 text-[10px] font-semibold uppercase tracking-widest text-cream/50">
              <Briefcase size={10} />
              {item.industry}
            </span>
          </div>

          <h3 className="mt-4 text-3xl font-extrabold tracking-tight text-cream">{item.title}</h3>
          <p className="mt-3 text-base leading-relaxed text-cream/60">{item.desc}</p>

          <div className="mt-6">
            <p className="text-xs font-semibold uppercase tracking-widest text-cream/40">Key Features</p>
            <div className="mt-3 grid gap-2.5 sm:grid-cols-2">
              {item.features.map((f) => (
                <span key={f} className="flex items-start gap-2.5 text-sm text-cream/70">
                  <Check size={14} className="mt-0.5 shrink-0 text-gold-400" strokeWidth={2.4} />
                  {f}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-6">
            <p className="text-xs font-semibold uppercase tracking-widest text-cream/40">Tech Stack</p>
            <div className="mt-3 flex flex-wrap gap-2">
              {item.tech.map((t) => (
                <span
                  key={t}
                  className="inline-flex items-center gap-1.5 rounded-full border border-white/10 bg-white/[0.04] px-3 py-1.5 text-xs font-medium text-cream/70"
                >
                  <Code size={11} className="text-gold-400" />
                  {t}
                </span>
              ))}
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <a
              href={`mailto:fekerimariammulat@gmail.com?subject=${encodeURIComponent(
                `Request Similar Website - ${item.title}`
              )}&body=${encodeURIComponent(
                `Hello Fekerimariam,

I saw the "${item.title}" concept and I would like to request a similar website for my business.

Please contact me to discuss the details.`
              )}`}
              className="btn-gold inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-bold"
            >
              <Mail size={15} strokeWidth={2.2} />
              Request Similar Website
            </a>
            <button
              onClick={onClose}
              className="btn-ghost inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-bold"
            >
              Close
            </button>
          </div>
        </div>
      </motion.div>
    </motion.div>
  );
}

export default function PortfolioShowcase() {
  const [filter, setFilter] = useState<string>("All");
  const [selected, setSelected] = useState<PortfolioItem | null>(null);
  const reduced = useReducedMotion();

  const items = filter === "All" ? PORTFOLIO : PORTFOLIO.filter((p) => p.category === filter);

  return (
    <section id="work" className="relative px-5 py-24 scroll-mt-24 md:px-8 md:py-32">
      <div className="pointer-events-none absolute right-[-10%] top-24 h-96 w-96 rounded-full bg-[#d4af37]/[0.07] blur-[130px]" />

      <div className="mx-auto max-w-7xl">
        <motion.div className="flex flex-col gap-8 lg:flex-row lg:items-end lg:justify-between" variants={fadeUp} initial={reduced ? "show" : "hidden"} whileInView="show" viewport={{ once: true, margin: "-60px" }}>
          <div className="max-w-2xl">
            <span className="eyebrow">Selected Work</span>
            <h2 className="section-title mt-4">
              Concepts built with <span className="gold-text">purpose and polish.</span>
            </h2>
            <p className="mt-5 text-base leading-relaxed text-cream/55 md:text-lg">
              A curated set of tailored concepts across business websites, landing pages, and portfolios. Each one shows how structure, messaging, and design work together.
            </p>
          </div>

          {/* Filter tabs */}
          <div className="flex flex-wrap gap-2">
            {CATEGORIES.map((cat) => (
              <button
                key={cat}
                onClick={() => setFilter(cat)}
                className={`rounded-full px-4 py-2 text-sm font-medium transition-all duration-300 ${
                  filter === cat
                    ? "btn-gold"
                    : "border border-white/10 bg-white/[0.03] text-cream/60 hover:border-gold-500/40 hover:text-gold-400"
                }`}
              >
                {cat}
              </button>
            ))}
          </div>
        </motion.div>

        {/* Grid */}
        <motion.div layout className="mt-12 grid gap-6 md:grid-cols-2 lg:grid-cols-3">
          <AnimatePresence mode="popLayout">
            {items.map((item) => (
              <motion.article
                key={item.title}
                layout
                className="glass-card group flex cursor-pointer flex-col overflow-hidden rounded-3xl transition-all duration-300 hover:-translate-y-1.5 hover:border-gold-500/35 hover:shadow-[0_28px_70px_-28px_rgba(212,175,55,0.3)]"
                initial={reduced ? { opacity: 1 } : { opacity: 0, y: 26 }}
                whileInView={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.96 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{ duration: 0.5, ease: [0.16, 1, 0.3, 1] as const }}
                onClick={() => setSelected(item)}
              >
                {/* Mockup with browser chrome */}
                <div className="relative h-48 overflow-hidden border-b border-white/[0.07]">
                  <div className="absolute inset-x-0 top-0 z-10 flex items-center gap-1.5 border-b border-white/[0.06] bg-[#0c1222]/90 px-4 py-2.5 backdrop-blur">
                    <span className="h-2 w-2 rounded-full bg-[#ff5f57]" />
                    <span className="h-2 w-2 rounded-full bg-[#febc2e]" />
                    <span className="h-2 w-2 rounded-full bg-[#28c840]" />
                  </div>
                  <ConceptMock item={item} />
                  <span className="absolute bottom-3 right-3 z-10 flex h-9 w-9 items-center justify-center rounded-full bg-[#0a0f1c]/90 text-gold-400 opacity-0 shadow-lg ring-1 ring-gold-500/40 backdrop-blur transition-all duration-300 group-hover:opacity-100">
                    <ArrowUpRight size={15} strokeWidth={2.2} />
                  </span>
                </div>

                {/* Body */}
                <div className="flex flex-1 flex-col p-6">
                  <div className="flex items-center justify-between gap-3">
                    <span className="rounded-full border border-gold-500/25 bg-gold-500/[0.08] px-2.5 py-1 text-[10px] font-semibold uppercase tracking-widest text-gold-400">
                      {item.badge}
                    </span>
                    <span className="text-[11px] font-medium text-cream/40">{item.category}</span>
                  </div>
                  <h3 className="mt-3.5 text-xl font-bold tracking-tight text-cream transition-colors group-hover:text-gold-400">
                    {item.title}
                  </h3>
                  <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-cream/55">{item.desc}</p>

                  <div className="mt-4 flex flex-wrap gap-1.5">
                    {item.tech.slice(0, 3).map((t) => (
                      <span key={t} className="rounded-md border border-white/[0.08] bg-white/[0.03] px-2 py-0.5 text-[11px] text-cream/45">
                        {t}
                      </span>
                    ))}
                    {item.tech.length > 3 && (
                      <span className="px-1 text-[11px] text-cream/35">+{item.tech.length - 3}</span>
                    )}
                  </div>

                  <span className="mt-auto inline-flex items-center gap-1.5 pt-5 text-sm font-semibold text-gold-400/90 transition-colors group-hover:text-gold-400">
                    View Project
                    <ArrowRight size={14} strokeWidth={2.2} className="transition-transform duration-300 group-hover:translate-x-1" />
                  </span>
                </div>
              </motion.article>
            ))}
          </AnimatePresence>
        </motion.div>

        {items.length === 0 && (
          <div className="glass-card mt-12 rounded-3xl p-12 text-center">
            <p className="text-cream/60">No projects in this category yet.</p>
          </div>
        )}
      </div>

      {/* Modal */}
      <AnimatePresence>
        {selected && <ProjectModal item={selected} onClose={() => setSelected(null)} />}
      </AnimatePresence>
    </section>
  );
}