import { motion, useReducedMotion } from "framer-motion";
import { Wand2, MonitorSmartphone, Target, MessageCircle, Zap, Layers } from "lucide-react";
import { REASONS } from "../data/portfolioData";

const ICONS: Record<string, typeof Wand2> = {
  wand: Wand2,
  smartphone: MonitorSmartphone,
  target: Target,
  chat: MessageCircle,
  zap: Zap,
};

const fadeUp = {
  hidden: { opacity: 0, y: 30 },
  show: { opacity: 1, y: 0, transition: { duration: 0.7, ease: [0.16, 1, 0.3, 1] as const } },
};

export default function AboutAndWhy() {
  const reduced = useReducedMotion();
  const animation = reduced ? {} : { initial: "hidden" as const, whileInView: "show" as const, viewport: { once: true, margin: "-80px" } };

  return (
    <section id="about" className="relative px-5 py-24 md:px-8 md:py-32">
      <div className="pointer-events-none absolute right-[-8%] top-10 h-80 w-80 rounded-full bg-[#d4af37]/[0.06] blur-[110px]" />

      <div className="mx-auto max-w-7xl">
        {/* About intro */}
        <motion.div className="max-w-3xl" variants={fadeUp} {...animation}>
          <span className="eyebrow">About Me</span>
          <h2 className="section-title mt-4">
            Design that makes your business look{" "}
            <span className="gold-text">as good as it is.</span>
          </h2>
        </motion.div>

        <motion.div
          className="mt-8 grid gap-10 lg:grid-cols-[1.4fr_1fr]"
          variants={fadeUp}
          {...animation}
        >
          <div className="space-y-5 text-base leading-relaxed text-cream/65 md:text-lg">
            <p>
              I am Fekerimariam Mulat, a web designer and digital creator based in Addis Ababa, Ethiopia. My focus is simple: build modern, responsive websites that give businesses real presence, real credibility, and real results online.
            </p>
            <p>
              From clean UI/UX and thoughtful typography to mobile-first layouts and fast, performance-minded builds, every project gets the same care: a website that looks premium on any device and is structured to turn visitors into customers.
            </p>
            <p className="text-cream/50">
              I keep learning, keep refining, and keep shipping work that businesses are proud to share. No fabricated credentials, no inflated claims. Just honest craft, clear communication, and websites that work.
            </p>
          </div>

          <div className="glass-card relative overflow-hidden rounded-3xl p-7">
            <div className="absolute -right-10 -top-10 h-32 w-32 rounded-full bg-[#d4af37]/10 blur-2xl" />
            <div className="flex items-center gap-3">
              <span className="flex h-11 w-11 items-center justify-center rounded-2xl bg-gold-500/15 text-gold-400">
                <Layers size={20} strokeWidth={1.8} />
              </span>
              <div>
                <p className="text-lg font-bold text-cream">What I bring</p>
                <p className="text-sm text-cream/45">to every engagement</p>
              </div>
            </div>
            <ul className="mt-6 space-y-3.5">
              {[
                "Modern UI/UX design thinking",
                "Fully responsive development",
                "Business-focused conversion structure",
                "Continuous learning and improvement",
              ].map((point) => (
                <li key={point} className="flex items-start gap-3 text-sm text-cream/70">
                  <span className="mt-1.5 h-1.5 w-1.5 shrink-0 rounded-full bg-gold-500" />
                  {point}
                </li>
              ))}
            </ul>
          </div>
        </motion.div>

        {/* Why work with me */}
        <div id="why-me" className="mt-28 scroll-mt-28">
          <motion.div className="max-w-2xl" variants={fadeUp} {...animation}>
            <span className="eyebrow">Why Work With Me</span>
            <h2 className="section-title mt-4">
              A partner who treats your website like{" "}
              <span className="gold-text">your business depends on it.</span>
            </h2>
          </motion.div>

          <div className="mt-12 grid gap-5 sm:grid-cols-2 lg:grid-cols-5">
            {REASONS.map((reason, i) => {
              const Icon = ICONS[reason.icon] ?? Wand2;
              return (
                <motion.div
                  key={reason.title}
                  className={`glass-card group relative overflow-hidden rounded-3xl p-6 transition-all duration-300 hover:-translate-y-1.5 hover:border-gold-500/35 ${
                    i === 2 ? "lg:col-span-1" : ""
                  }`}
                  initial={reduced ? { opacity: 1 } : { opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, margin: "-60px" }}
                  transition={{ duration: 0.6, delay: (i % 3) * 0.1, ease: [0.16, 1, 0.3, 1] as const }}
                >
                  <div className="absolute -right-6 -top-6 h-20 w-20 rounded-full bg-[#d4af37]/[0.07] blur-xl transition-all duration-300 group-hover:bg-[#d4af37]/[0.16]" />
                  <span className="relative flex h-11 w-11 items-center justify-center rounded-2xl bg-gold-500/12 text-gold-400">
                    <Icon size={20} strokeWidth={1.8} />
                  </span>
                  <h3 className="relative mt-5 text-base font-bold leading-snug text-cream">
                    {reason.title}
                  </h3>
                  <p className="relative mt-2.5 text-sm leading-relaxed text-cream/55">
                    {reason.desc}
                  </p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </div>
    </section>
  );
}