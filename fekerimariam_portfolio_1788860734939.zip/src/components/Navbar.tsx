import { useEffect, useState } from "react";
import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { PhoneCall, Menu, X } from "lucide-react";
import { BRAND, NAV_LINKS } from "../data/portfolioData";

export default function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const reduced = useReducedMotion();

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  // Lock body scroll when the mobile menu is open
  useEffect(() => {
    document.body.style.overflow = open ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [open]);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled ? "glass-nav border-b border-white/10 py-3 shadow-[0_10px_40px_-20px_rgba(0,0,0,0.9)]" : "py-5"
      }`}
    >
      <nav className="mx-auto flex max-w-7xl items-center justify-between px-5 md:px-8">
        {/* Brand */}
        <a href="#top" className="group flex items-center gap-3">
          <span className="flex h-10 w-10 items-center justify-center rounded-xl bg-gradient-to-br from-[#e5c05b] to-[#b8942a] font-extrabold tracking-tight text-[#0a0e18] shadow-[0_8px_24px_-8px_rgba(212,175,55,0.7)]">
            FM
          </span>
          <span className="hidden sm:block leading-tight">
            <span className="block text-sm font-bold tracking-tight text-cream">Fekerimariam Mulat</span>
            <span className="block text-[11px] uppercase tracking-[0.18em] text-gold-500/80">Web Designer & Digital Creator</span>
          </span>
        </a>

        {/* Desktop links */}
        <div className="hidden items-center gap-1 lg:flex">
          {NAV_LINKS.map((link) => (
            <a
              key={link.href}
              href={link.href}
              className="rounded-full px-4 py-2 text-sm font-medium text-cream/70 transition-all hover:bg-white/5 hover:text-gold-400"
            >
              {link.label}
            </a>
          ))}
        </div>

        {/* Call + mobile toggle */}
        <div className="flex items-center gap-3">
          <a
            href={`tel:${BRAND.phonePrimary}`}
            className="btn-gold hidden items-center gap-2 rounded-full px-5 py-2.5 text-sm font-bold md:inline-flex"
          >
            <PhoneCall size={16} strokeWidth={2.2} />
            Call Me
          </a>
          <button
            aria-label="Open menu"
            onClick={() => setOpen(true)}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-cream transition-colors hover:border-gold-500/40 lg:hidden"
          >
            <Menu size={20} />
          </button>
        </div>
      </nav>

      {/* Mobile sheet */}
      <AnimatePresence>
        {open && (
          <motion.div
            className="fixed inset-0 z-[60] lg:hidden"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.25 }}
          >
            <div className="absolute inset-0 bg-[#050810]/80 backdrop-blur-sm" onClick={() => setOpen(false)} />
            <motion.div
              className="absolute right-0 top-0 flex h-full w-[86%] max-w-sm flex-col border-l border-white/10 bg-[#0a0f1c] p-6 shadow-2xl"
              initial={{ x: "100%" }}
              animate={{ x: 0 }}
              exit={{ x: "100%" }}
              transition={reduced ? { duration: 0 } : { type: "spring", stiffness: 320, damping: 34 }}
            >
              <div className="flex items-center justify-between">
                <span className="text-sm font-bold text-cream">Fekerimariam Mulat</span>
                <button
                  aria-label="Close menu"
                  onClick={() => setOpen(false)}
                  className="flex h-10 w-10 items-center justify-center rounded-xl border border-white/10 bg-white/5 text-cream transition-colors hover:border-gold-500/40"
                >
                  <X size={20} />
                </button>
              </div>

              <div className="mt-10 flex flex-col gap-1">
                {NAV_LINKS.map((link, i) => (
                  <motion.a
                    key={link.href}
                    href={link.href}
                    onClick={() => setOpen(false)}
                    className="rounded-2xl px-4 py-4 text-2xl font-bold tracking-tight text-cream/85 transition-all hover:bg-white/5 hover:text-gold-400"
                    initial={{ opacity: 0, x: 24 }}
                    animate={{ opacity: 1, x: 0 }}
                    transition={{ delay: 0.06 * i + 0.1, duration: 0.35 }}
                  >
                    {link.label}
                  </motion.a>
                ))}
              </div>

              <div className="mt-auto flex flex-col gap-3">
                <a
                  href={`tel:${BRAND.phonePrimary}`}
                  className="btn-gold flex items-center justify-center gap-2 rounded-full px-5 py-3.5 text-sm font-bold"
                >
                  <PhoneCall size={16} strokeWidth={2.2} />
                  Call {BRAND.phonePrimary}
                </a>
                <p className="text-center text-xs text-cream/40">
                  {BRAND.location} · Serving global & local businesses
                </p>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}