export const BRAND = {
  name: "Fekerimariam Mulat",
  role: "Web Designer & Digital Creator",
  location: "Addis Ababa, Ethiopia",
  email: "fekerimariammulat@gmail.com",
  phonePrimary: "0913602094",
  phonePrimaryIntl: "+251913602094",
  phoneSecondary: "0708175310",
  phoneSecondaryIntl: "+251708175310",
};

export const NAV_LINKS = [
  { label: "Services", href: "#services" },
  { label: "Work", href: "#work" },
  { label: "Why Me", href: "#why-me" },
  { label: "Process", href: "#process" },
  { label: "Contact", href: "#contact" },
] as const;

export interface Reason {
  title: string;
  desc: string;
  icon: string;
}

export const REASONS: Reason[] = [
  {
    title: "Custom Tailored Approach",
    desc: "Every website is designed around your business goals, brand identity, and the people you want to reach. No templates, no shortcuts.",
    icon: "wand",
  },
  {
    title: "Mobile-First & Responsive Thinking",
    desc: "Your site is built for phones first, then perfected for tablets and desktops, so it looks sharp on every screen size.",
    icon: "smartphone",
  },
  {
    title: "Business-Focused Conversion Structure",
    desc: "Clear messaging, strategic calls to action, and a layout that guides visitors toward contacting you or buying from you.",
    icon: "target",
  },
  {
    title: "Clear, Transparent Communication",
    desc: "You always know what is happening, what it costs, and when it will be delivered. No jargon, no surprises, no ghosting.",
    icon: "chat",
  },
  {
    title: "Fast, High-Performance Delivery",
    desc: "Optimized code, quick load times, and a streamlined workflow that gets your website live without endless waiting.",
    icon: "zap",
  },
];

export interface PortfolioItem {
  title: string;
  category: string;
  badge: string;
  desc: string;
  industry: string;
  features: string[];
  tech: string[];
  tint: string;
  pattern: "hero" | "grid" | "split";
}

export const CATEGORIES = ["All", "Business", "Landing Pages", "Portfolios & UI Concepts"] as const;

export const PORTFOLIO: PortfolioItem[] = [
  {
    title: "Addis Coffee Roasters",
    category: "Business",
    badge: "Business Website Concept",
    desc: "A premium business website concept for a specialty coffee roastery, combining story-driven branding with clear retail and wholesale conversion paths.",
    industry: "Coffee & Agriculture",
    features: [
      "Story-driven brand narrative section",
      "Wholesale inquiry funnel with clear CTA",
      "Product showcase with tasting notes",
      "About and sourcing transparency page",
    ],
    tech: ["React", "Tailwind CSS", "Framer Motion", "Responsive"],
    tint: "#c98a2b",
    pattern: "hero",
  },
  {
    title: "Horizon Real Estate",
    category: "Business",
    badge: "Business Website Concept",
    desc: "A modern business platform concept for an Addis Ababa real estate firm, designed to turn property listings into qualified client inquiries.",
    industry: "Real Estate & Property",
    features: [
      "Featured listings grid with filters",
      "Agent and project spotlight sections",
      "Inquiry form wired to direct contact",
      "Neighborhood guide content blocks",
    ],
    tech: ["TypeScript", "Tailwind CSS", "Vite", "Responsive"],
    tint: "#3e8ea0",
    pattern: "grid",
  },
  {
    title: "Tena Health Clinic",
    category: "Business",
    badge: "Business Website Concept",
    desc: "A calm and trustworthy website concept for a health clinic, built around easy appointment booking and clear service information.",
    industry: "Healthcare & Wellness",
    features: [
      "One-tap appointment request flow",
      "Service categories with detailed pages",
      "Doctor profile cards with credentials",
      "Accessible, high-contrast interface",
    ],
    tech: ["React", "Tailwind CSS", "Accessible", "Responsive"],
    tint: "#5da08a",
    pattern: "split",
  },
  {
    title: "Zemen Digital Marketing",
    category: "Landing Pages",
    badge: "Website Concept",
    desc: "A high-converting landing page concept for a digital marketing agency, architected to capture leads from the very first scroll.",
    industry: "Marketing & Digital Services",
    features: [
      "Above-the-fold lead capture",
      "Service pillars with proof points",
      "Testimonial and results sections",
      "Single, repeated conversion CTA",
    ],
    tech: ["React", "Tailwind CSS", "Framer Motion", "SEO Ready"],
    tint: "#a34dcd",
    pattern: "hero",
  },
  {
    title: "Ethio Voyage Tours",
    category: "Landing Pages",
    badge: "Landing Page Concept",
    desc: "An immersive landing page concept for an Ethiopia tour operator, turning breathtaking destinations into bookable travel experiences.",
    industry: "Tourism & Hospitality",
    features: [
      "Full-screen destination showcases",
      "Itinerary cards with pricing tiers",
      "WhatsApp quick inquiry shortcuts",
      "Seasonal tour spotlight blocks",
    ],
    tech: ["React", "Tailwind CSS", "Responsive", "Fast Load"],
    tint: "#c45a3c",
    pattern: "grid",
  },
  {
    title: "Selam Fashion Studio",
    category: "Landing Pages",
    badge: "Website Concept",
    desc: "A landing page concept for a fashion studio with a bold editorial layout that puts the collection and the brand aesthetic first.",
    industry: "Fashion & Retail",
    features: [
      "Editorial lookbook layout",
      "Collection categories with filters",
      "Instagram-style gallery integration",
      "Direct order and inquiry buttons",
    ],
    tech: ["TypeScript", "Tailwind CSS", "Framer Motion", "Responsive"],
    tint: "#b0608a",
    pattern: "split",
  },
  {
    title: "Portfolio of Fekerimariam",
    category: "Portfolios & UI Concepts",
    badge: "Portfolio Project",
    desc: "This very website. A dark slate and gold portfolio concept that presents web design services with an agency-grade finish.",
    industry: "Personal Branding",
    features: [
      "Sticky glassmorphic navigation",
      "Interactive services and process grids",
      "Filterable project showcase with modals",
      "One-click call, WhatsApp, and email actions",
    ],
    tech: ["React", "TypeScript", "Tailwind CSS", "Framer Motion"],
    tint: "#d4af37",
    pattern: "hero",
  },
  {
    title: "Habesha Foods",
    category: "Portfolios & UI Concepts",
    badge: "Website Concept",
    desc: "A vibrant website concept for a traditional food brand, combining rich heritage storytelling with a modern e-commerce ready structure.",
    industry: "Food & Consumer Goods",
    features: [
      "Heritage story and recipe sections",
      "Product range showcase grid",
      "Retailer and export contact routes",
      "Cultural color and texture system",
    ],
    tech: ["React", "Tailwind CSS", "Responsive", "SEO Friendly"],
    tint: "#7c9c3e",
    pattern: "grid",
  },
];

export interface Service {
  title: string;
  desc: string;
  icon: string;
  tag: string;
}

export const SERVICES: Service[] = [
  {
    title: "Business Website Design",
    desc: "A complete, professional website built to represent your business with credibility and clarity online.",
    icon: "globe",
    tag: "Core",
  },
  {
    title: "Website Redesign",
    desc: "Transform an outdated, slow, or unprofessional site into a modern experience that earns trust instantly.",
    icon: "sparkles",
    tag: "Popular",
  },
  {
    title: "Responsive Website Development",
    desc: "Pixel-perfect development that adapts beautifully to every phone, tablet, and desktop screen.",
    icon: "monitor",
    tag: "Core",
  },
  {
    title: "High-Converting Landing Pages",
    desc: "Focused single pages designed to turn visitors into leads, bookings, and customers.",
    icon: "target",
    tag: "Growth",
  },
  {
    title: "Creative Portfolio Websites",
    desc: "A stunning digital showcase for creatives, freelancers, and professionals who want to stand out.",
    icon: "palette",
    tag: "Creative",
  },
  {
    title: "Modern UI/UX Design",
    desc: "Clean, intuitive interfaces and thoughtful user flows that make your website effortless to use.",
    icon: "pen",
    tag: "Design",
  },
  {
    title: "Website Performance Optimization",
    desc: "Faster load times, smoother interactions, and technical polish that keeps visitors engaged.",
    icon: "zap",
    tag: "Speed",
  },
  {
    title: "Basic SEO-Friendly Website Structure",
    desc: "Clean markup and smart structure that help your business get found on Google from day one.",
    icon: "search",
    tag: "SEO",
  },
];

export interface ProcessStep {
  index: string;
  title: string;
  desc: string;
}

export const PROCESS: ProcessStep[] = [
  {
    index: "01",
    title: "Discovery",
    desc: "Understanding your business objectives, target audience, and competitive edge.",
  },
  {
    index: "02",
    title: "Strategy",
    desc: "Sitemap, content architecture, and conversion funnel planning.",
  },
  {
    index: "03",
    title: "Design",
    desc: "Bespoke UI layouts, typography, and your own gold and dark slate styling.",
  },
  {
    index: "04",
    title: "Development",
    desc: "Clean code, lightning fast load times, and responsive perfection.",
  },
  {
    index: "05",
    title: "Launch & Improve",
    desc: "Testing, domain rollout, SEO essentials, and continuous support.",
  },
];

export const TIMELINE_CHOICES = [
  "Under 2 weeks",
  "2 to 4 weeks",
  "1 to 2 months",
  "Flexible",
] as const;

export const BUDGET_CHOICES = [
  "Less than 15,000 ETB",
  "15,000 to 40,000 ETB",
  "40,000 ETB and above",
  "Not sure yet",
] as const;

export function whatsappLink(text: string): string {
  return `https://wa.me/${BRAND.phonePrimaryIntl.replace("+", "")}?text=${encodeURIComponent(text)}`;
}

export function mailtoProjectInquiry(subject: string, body: string): string {
  return `mailto:${BRAND.email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
}