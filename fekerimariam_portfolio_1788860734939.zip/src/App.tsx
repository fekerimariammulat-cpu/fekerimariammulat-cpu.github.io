import { motion, AnimatePresence, useReducedMotion } from "framer-motion";
import { PhoneCall, MessageCircle, Mail, ArrowUp } from "lucide-react";
import { useEffect, useState } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import AboutAndWhy from "./components/AboutAndWhy";
import ServicesAndProcess from "./components/ServicesAndProcess";
import PortfolioShowcase from "./components/PortfolioShowcase";
import ContactAndFooter from "./components/ContactAndFooter";
import { BRAND, whatsappLink } from "./data/portfolioData";

function FloatingDock() {
  const reduced = useReducedMotion();

  return (
    <motion.div
      className="fixed bottom-5 right-5 z-40 flex items-center gap-2 rounded-full border border-white/10 bg-[#0a0f1c]/85 p-2 shadow-[0_16px_50px_-16px_rgba(0,0,0,0.9)] backdrop-blur-xl"
      initial={reduced ? { opacity: 1, y: 0 } : { opacity: 0, y: 24 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ delay: 1.1, duration: 0.6, ease: [0.16, 1, 0.3, 1] as const }}
    >
      <span className="hidden pl-2 text-[10px] font-semibold uppercase tracking-widest text-cream/40 sm:block">
        Quick Contact
      </span>
      <a
        href={`tel:${BRAND.phonePrimary}`}
        aria-label="Call Fekerimariam"
        title="Call now"
        className="flex h-10 w-10 items-center justify-center rounded-full bg-gradient-to-br from-[#e5c05b] to-[#b8942a] text-[#0a0e18] shadow-[0_8px_24px_-8px_rgba(212,175,55,0.7)] transition-transform duration-200 hover:scale-110 active:scale-95"
      >
        <PhoneCall size={17} strokeWidth={2.2} />
      </a>
      <a
        href={whatsappLink("Hello Fekerimariam, I would like to discuss a website project.")}
        target="_blank"
        rel="noreferrer"
        aria-label="Chat on WhatsApp"
        title="WhatsApp"
        className="flex h-10 w-10 items-center justify-center rounded-full border border-gold-500/30 bg-gold-500/10 text-gold-400 transition-transform duration-200 hover:scale-110 active:scale-95"
      >
        <MessageCircle size={17} strokeWidth={2.2} />
      </a>
      <a
        href={`mailto:${BRAND.email}`}
        aria-label="Send an email"
        title="Email"
        className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 bg-white/[0.05] text-cream/80 transition-transform duration-200 hover:scale-110 active:scale-95"
      >
        <Mail size={17} strokeWidth={2.2} />
      </a>
    </motion.div>
  );
}

function ScrollTop() {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const onScroll = () => setVisible(window.scrollY > 700);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <AnimatePresence>
      {visible && (
        <motion.a
          href="#top"
          aria-label="Back to top"
          className="fixed bottom-5 left-5 z-40 flex h-11 w-11 items-center justify-center rounded-full border border-white/10 bg-[#0a0f1c]/85 text-gold-400 shadow-[0_16px_50px_-16px_rgba(0,0,0,0.9)] backdrop-blur-xl transition-colors hover:border-gold-500/40"
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          exit={{ opacity: 0, scale: 0.8 }}
          transition={{ duration: 0.25 }}
        >
          <ArrowUp size={17} strokeWidth={2.2} />
        </motion.a>
      )}
    </AnimatePresence>
  );
}

function BackgroundAmbiance() {
  return (
    <div className="pointer-events-none fixed inset-0 z-0" aria-hidden>
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_80%_50%_at_50%_-10%,rgba(29,58,143,0.18),transparent_70%)]" />
      <div className="absolute inset-0 bg-[radial-gradient(ellipse_60%_40%_at_100%_100%,rgba(212,175,55,0.07),transparent_70%)]" />
      <div className="noise-overlay" />
    </div>
  );
}

function App() {
  return (
    <div className="relative min-h-screen overflow-x-hidden bg-obsidian text-cream">
      <BackgroundAmbiance />
      <div className="relative z-10">
        <Navbar />
        <main>
          <Hero />
          <AboutAndWhy />
          <ServicesAndProcess />
          <PortfolioShowcase />
          <ContactAndFooter />
        </main>
        <FloatingDock />
        <ScrollTop />
      </div>
    </div>
  );
}

export default App;